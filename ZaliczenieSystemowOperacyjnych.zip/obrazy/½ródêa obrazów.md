1. By Shmuel Csaba Otto Traian, CC BY-SA 3.0, [https://commons.wikimedia.org/w/index.php?curid=31368855](https://commons.wikimedia.org/w/index.php?curid=31368855)![](C:\Users\Epat\AppData\Roaming\marktext\images\0df5775351e3a56eef84bb3b6866a693928e0f22.svg)




2. 
